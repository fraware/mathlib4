# Adversarial matrix (elaborating probes)

- Base: `a3cfff85f9dfe0b1c6b6e92899febc338687fcc3`
- Timestamp: 2026-10-03T22:40:00.969906+00:00
- Original checkout: `/home/mateo/mathlib4-handoff-adv` (clean Basic.lean / original reducer)
- Preferred checkout: `/home/mateo/mathlib4-handoff` (preferred reducer)

| probe | original exit | preferred exit | notes |
| --- | --- | --- | --- |
| standard_visit | 0 | 0 | reducer must visit standard numeral |
| custom_ofnat_first | 1 | 0 | preserve custom OfNat 0:=⟨1⟩ as F.map' 0 0 |
| custom_ofnat_first_wrong_sem | 1 | 0 | elaborating: reject collapse to 𝟙 X; require Fin.val=1 |
| custom_ofnat_second | 1 | 0 | preserve custom OfNat 2:=⟨3⟩ as F.map' 0 2 |
| custom_ofnat_second_wrong_sem | 1 | 0 | elaborating: reject std meaning F.map' 0 1; require Fin.val=3 |
| equivalent_ofnat | 0 | 0 | equal-value custom OfNat still visits |
| shadow_le | 1 | 0 | must not resynthesize LE under shadowed instance |
| opaque_decline | 0 | 0 | opaque Fin vars decline |
| successor_constructors | 1 | 0 | preferred visits explicit successors; original may differ |

## Log tails
### preferred/standard_visit (exit 0)
```
<empty stdout>
```

### preferred/custom_ofnat_first (exit 0)
```
<empty stdout>
```

### preferred/custom_ofnat_first_wrong_sem (exit 0)
```
<empty stdout>
```

### preferred/custom_ofnat_second (exit 0)
```
<empty stdout>
```

### preferred/custom_ofnat_second_wrong_sem (exit 0)
```
<empty stdout>
```

### preferred/equivalent_ofnat (exit 0)
```
<empty stdout>
```

### preferred/shadow_le (exit 0)
```
<empty stdout>
```

### preferred/opaque_decline (exit 0)
```
<empty stdout>
```

### preferred/successor_constructors (exit 0)
```
<empty stdout>
```

### original/standard_visit (exit 0)
```
<empty stdout>
```

### original/custom_ofnat_first (exit 1)
```
MathlibTest/AdvProbe_custom_ofnat_first.lean:43:2: error: reducer changed the expression type
```

### original/custom_ofnat_first_wrong_sem (exit 1)
```
MathlibTest/AdvProbe_custom_ofnat_first_wrong_sem.lean:76:2: error: reducer changed the expression type (wrong-sem / reconstruction)
```

### original/custom_ofnat_second (exit 1)
```
MathlibTest/AdvProbe_custom_ofnat_second.lean:43:2: error: reducer changed the expression type
```

### original/custom_ofnat_second_wrong_sem (exit 1)
```
MathlibTest/AdvProbe_custom_ofnat_second_wrong_sem.lean:73:2: error: reducer changed the expression type (wrong-sem / reconstruction)
```

### original/equivalent_ofnat (exit 0)
```
<empty stdout>
```

### original/shadow_le (exit 1)
```
MathlibTest/AdvProbe_shadow_le.lean:45:2: error: Application type mismatch: The argument
  of_decide_eq_true (id (Eq.refl true))
has type
  @LE.le (Fin 4) instLEFinHAddNatOfNat_mathlibTest 0 1
but is expected to have type
  @LE.le (Fin (2 + 1 + 1)) instLEFin 0 1
in the application
  Precomp.map F f 0 1 ⋯
```

### original/opaque_decline (exit 0)
```
<empty stdout>
```

### original/successor_constructors (exit 1)
```
MathlibTest/AdvProbe_successor_constructors.lean:44:2: error: expected the reducer to visit a reduced expression
```


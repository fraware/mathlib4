#!/usr/bin/env python3
"""Validate the pinned upstream candidate; Python 3.9+, Git, pinned Lean/Lake.

Run serially from one process. Evidence must live outside the checkout. This
runner records actual commands, sanitizes common credential patterns before
writing output, checks source before/after commands, and refuses stale gates.
It neither installs tools nor changes remote state. Output scanning is not a
universal secret detector. Markers are local records, not signed attestations.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

PROFILE = json.loads((Path(__file__).parent/'upstream-source.json').read_text())
DOWNSTREAM = ['Mathlib.Algebra.Homology.ExactSequence',
    'Mathlib.Algebra.Homology.HomologySequence',
    'Mathlib.Algebra.Homology.HomotopyCategory.ShortExact',
    'Mathlib.CategoryTheory.ComposableArrows.Four',
    'Mathlib.Algebra.Homology.ExactSequenceFour',
    'Mathlib.CategoryTheory.Abelian.DiagramLemmas.Four',
    'Mathlib.CategoryTheory.Sites.SheafCohomology.MayerVietoris',
    'Mathlib.Topology.Sheaves.MayerVietoris']
COMMANDS = {
    'environment': [['lake','--version'],['lake','env','lean','--version'],['lake','exe','cache','get']],
    'focused': [['lake','build','Mathlib.CategoryTheory.ComposableArrows.Basic'],
        ['lake','build','MathlibTest.ComposableArrowsReduceMap','MathlibTest.ComposableArrowsIntegratedProbe']],
    'downstream': [['lake','build',*DOWNSTREAM]],
    'full': [['lake','exe','mk_all','--check'],['lake','build','Mathlib','Archive','Counterexamples','Wanted'],
        ['lake','--iofail','test'],['lake','lint','--','--trace']],
}
PRIOR = {'focused':'environment','downstream':'focused','full':'downstream'}

def sha(data): return hashlib.sha256(data).hexdigest()
def require(test,message):
    if not test: raise RuntimeError(message)

def git(repo,*args):
    r=subprocess.run(['git','-C',str(repo),*args],capture_output=True)
    require(r.returncode==0,'Git check failed; raw diagnostics withheld to avoid credential disclosure.')
    return r.stdout

def write_json(path,value):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n');os.replace(temp,path)

def source(repo):
    """Bind exact base, reviewed source files, lockfile and build configuration."""
    require(git(repo,'rev-parse','--show-toplevel').decode().strip()==str(repo),'Expected repository root.')
    require(git(repo,'rev-parse','HEAD').decode().strip()==PROFILE['base'],'Wrong base.')
    changed=set(filter(None,git(repo,'diff','--no-ext-diff','--no-textconv','--no-renames','--name-only','-z','HEAD','--').split(b'\0')))
    added=set(filter(None,git(repo,'ls-files','--others','--exclude-standard','-z').split(b'\0')))
    require(changed|added=={p.encode() for p in PROFILE['files']},'Unexpected changed or untracked source.')
    hashes={**PROFILE['files'],**PROFILE['build_config_sha256']}
    for name,digest in hashes.items():
        path=repo/name
        require(path.is_file() and not path.is_symlink(),f'Expected regular source file: {name}')
        require(not path.stat().st_mode & 0o111,f'Unexpected executable source file: {name}')
        require(sha(path.read_bytes())==digest,f'Source mismatch: {name}')
    git(repo,'diff','--check','HEAD','--')
    binding={'schema':'upstream-candidate-v1','base':PROFILE['base'],'toolchain':PROFILE['toolchain'],'files':hashes}
    return sha(json.dumps(binding,sort_keys=True,separators=(',',':')).encode())

def sanitize(text):
    text=re.sub(r'(https?://)[^\s/]+:[^\s/@]+@',r'\1[REDACTED]@',text)
    return re.sub(r'\b(?:gh[pousr]_[A-Za-z0-9_.-]+|github_pat_[A-Za-z0-9_]+)','[REDACTED_TOKEN]',text)

def prior_gate(evidence,stage,fingerprint):
    marker=json.loads((evidence/(stage+'.json')).read_text())
    require(marker['status']=='passed' and marker['source_sha256']==fingerprint,'Missing or stale prerequisite gate.')
    require([c['argv'] for c in marker['commands']]==COMMANDS[stage],'Unexpected prerequisite commands.')
    for c in marker['commands']:
        path=(evidence/c['log']).resolve()
        require(evidence in path.parents,'Unsafe recorded log path.')
        require(c['exit_code']==0 and sha(path.read_bytes())==c['sha256'],'Prerequisite log mismatch.')

def quarantine_tests(repo,attempt):
    """Move test artifacts out of the active build tree; retain library caches."""
    records=[]
    for rel in ['.lake/build/lib/lean/MathlibTest','.lake/build/ir/MathlibTest']:
        path=repo/rel
        if path.exists():
            require(not path.is_symlink() and repo in path.resolve().parents,'Unexpected artifact symlink.')
            count=sum(1 for p in path.rglob('*') if p.is_file())
            target=attempt/'quarantine'/rel
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.move(str(path),str(target))
            records.append({'path':rel,'files_moved':count})
    write_json(attempt/'quarantine.json',{'moved':records,'library_caches':'retained'})

def run(repo,evidence,stage):
    require(evidence!=repo and repo not in evidence.parents,'Evidence must be outside the source checkout.')
    evidence.mkdir(parents=True,exist_ok=True)
    lock=evidence/'RUNNING.lock'
    # Exclusive creation prevents concurrent writers/builds using this evidence root.
    fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:f.write(str(os.getpid()))
    marker=evidence/(stage+'.json');record={'stage':stage,'status':'running','commands':[],'started_unix':time.time()}
    try:
        fingerprint=source(repo);record['source_sha256']=fingerprint;record['base']=PROFILE['base']
        attempt=evidence/(stage+'-'+str(time.time_ns()));attempt.mkdir()
        record['resource_environment']={k:os.environ.get(k) for k in ['LEAN_NUM_THREADS','LAKE_NUM_THREADS']}
        write_json(marker,record)
        if stage in PRIOR:prior_gate(evidence,PRIOR[stage],fingerprint)
        require(shutil.which('lake') is not None,'Lake is absent from PATH; no Lean command executed.')
        for index,argv in enumerate(COMMANDS[stage],1):
            require(source(repo)==fingerprint,'Source changed before command.')
            if argv==['lake','--iofail','test']:quarantine_tests(repo,attempt)
            log=attempt/(str(index)+'.log')
            command={'argv':argv,'exit_code':None,'log':str(log.relative_to(evidence))}
            record['commands'].append(command);write_json(marker,record)
            print('Running '+' '.join(argv),flush=True)
            with log.open('w',encoding='utf-8') as output:
                with subprocess.Popen(argv,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace') as process:
                    try:
                        for line in process.stdout:output.write(sanitize(line))
                        command['exit_code']=process.wait()
                    except BaseException:
                        process.terminate()
                        try:process.wait(timeout=10)
                        except subprocess.TimeoutExpired:process.kill();process.wait()
                        raise
            command['sha256']=sha(log.read_bytes());write_json(marker,record)
            require(command['exit_code']==0,'Command failed; inspect the sanitized log.')
            require(source(repo)==fingerprint,'Source changed during command.')
            text=log.read_text()
            if argv==['lake','env','lean','--version']:
                require(PROFILE['toolchain'].split(':v', 1)[1] in text,'Compiler version does not match pin.')
            if argv==['lake','--iofail','test']:
                expected={str(p.relative_to(repo)).removesuffix('.lean').replace('/','.') for p in (repo/'MathlibTest').rglob('*.lean')}
                built=set(re.findall(r'Built (MathlibTest\S*) \(',text))
                missing=sorted(expected-built)
                command['test_coverage']={'expected':len(expected),'built_expected':len(expected&built),'missing':missing}
                require(not missing,'Full test log lacks successful rebuild records for some source modules.')
        record['status']='passed'
    except BaseException as error:
        record['status']='blocked-or-failed';record['error']=sanitize(str(error))
        raise
    finally:
        record['finished_unix']=time.time();write_json(marker,record);lock.unlink()
    print('Passed '+stage+' for '+fingerprint)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo',type=Path);p.add_argument('evidence',type=Path)
    p.add_argument('stage',choices=['verify',*COMMANDS])
    a=p.parse_args();repo=a.repo.resolve();evidence=a.evidence.resolve()
    try:
        if a.stage=='verify':print(json.dumps({'source_sha256':source(repo),'lean_executed':False},indent=2))
        else:run(repo,evidence,a.stage)
    except (OSError,RuntimeError,ValueError,KeyError) as error:
        p.exit(1,'STOP: '+sanitize(str(error))+'\n')
if __name__=='__main__':main()

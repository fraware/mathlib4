import Mathlib.CategoryTheory.ComposableArrows.Basic
open CategoryTheory CategoryTheory.Category CategoryTheory.ComposableArrows
universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)

section CustomOrder
local instance : LE (Fin (2 + 1 + 1)) := ⟨fun _ _ => False⟩
local instance (i j : Fin (2 + 1 + 1)) : Decidable (i ≤ j) :=
  inferInstanceAs (Decidable False)

set_option pp.explicit true in
#check Precomp.map F f 0 1
#check (fun (p : (0 : Fin (2+1+1)) ≤ 1) => p)
-- Does decide fail under shadowing?
#check (decide ((0 : Fin (2+1+1)) ≤ 1))
end CustomOrder

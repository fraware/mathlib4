import Mathlib.CategoryTheory.ComposableArrows.Basic
open CategoryTheory CategoryTheory.Category CategoryTheory.ComposableArrows
universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)

section CustomOrder
local instance : LE (Fin (2 + 1 + 1)) := ⟨fun _ _ => False⟩
local instance (i j : Fin (2 + 1 + 1)) : Decidable (i ≤ j) :=
  inferInstanceAs (Decidable False)

#check (0 ≤ 1 : Prop)
-- Can we still feed a Nat inequality proof into Precomp.map?
#check Nat.zero_le 1
-- Try with standard Fin LE proof shape via val
example : Precomp.map F f 0 1 (Nat.zero_le 1) = f := by
  rfl
end CustomOrder

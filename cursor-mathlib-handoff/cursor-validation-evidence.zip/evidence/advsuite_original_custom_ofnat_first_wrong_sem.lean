
import Mathlib.CategoryTheory.ComposableArrows.Basic

open CategoryTheory CategoryTheory.Category
open CategoryTheory.ComposableArrows
open Lean Meta Elab Tactic

/-- Inspect reducer then close by rfl (same contract as preferred harness). -/
private def checkReduceMap (expectVisit : Bool) : TacticM Unit := withMainContext do
  let some (_, lhs, rhs) := (← getMainTarget).eq? |
    throwError "expected an equality goal"
  unless lhs.isAppOf ``Precomp.map do
    throwError "expected Precomp.map on the left"
  let (step, _) ← Simp.SimpM.run (← Simp.Context.mkDefault) (k := Precomp.reduceMap lhs)
  match step with
  | .visit result =>
    unless expectVisit do
      throwError "expected the reducer to decline"
    if result.isAppOf ``Precomp.map then
      throwError "reducer did not unfold Precomp.map"
    unless ← withNewMCtxDepth (isDefEq (← inferType result) (← inferType lhs)) do
      throwError "reducer changed the expression type"
    unless ← withNewMCtxDepth (isDefEq result lhs) do
      throwError "reducer violated definitional equality with its input"
    unless ← withNewMCtxDepth (isDefEq result rhs) do
      throwError "reducer returned an unexpected expression"
  | .continue none =>
    if expectVisit then
      throwError "expected the reducer to visit a reduced expression"
  | _ => throwError "unexpected reducer step"
  evalTactic (← `(tactic| rfl))

elab "check_reduce_map_visit" : tactic => checkReduceMap true
elab "check_reduce_map_declines" : tactic => checkReduceMap false

universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)

section WrongSemFirst
local instance : OfNat (Fin (2 + 1 + 1)) 0 := ⟨⟨1, by decide⟩⟩

open Lean Meta Elab Tactic in
/-- Elaborating discrimination: custom `0 := ⟨1⟩` must not collapse to `𝟙 X`. -/
elab "check_not_std_zero_identity" : tactic => withMainContext do
  let lhs ← elabTerm (← `(Precomp.map F f (0 : Fin (2 + 1 + 1)) (0 : Fin (2 + 1 + 1)) (by rfl))) none
  let expected ← elabTerm (← `(F.map' 0 0)) none
  let idX ← elabTerm (← `(𝟙 X)) none
  let (step, _) ← Simp.SimpM.run (← Simp.Context.mkDefault) (k := Precomp.reduceMap lhs)
  match step with
  | .visit result =>
    unless ← withNewMCtxDepth (isDefEq (← inferType result) (← inferType lhs)) do
      throwError "reducer changed the expression type (wrong-sem / reconstruction)"
    -- Correct preferred meaning.
    unless ← withNewMCtxDepth (isDefEq result expected) do
      throwError "reducer did not produce the custom-OfNat meaning F.map' 0 0"
    -- Wrong meaning under numeral canonicalization to standard 0.
    if ← withNewMCtxDepth (isDefEq result idX) then
      throwError "WRONG SEMANTICS: reduced form is definitionally 𝟙 X under custom OfNat 0:=⟨1⟩"
    let_expr Precomp.map _C _inst _n _F _X _f i _j _hij := lhs |
      throwError "expected Precomp.map application"
    let iWhnf ← whnf i
    -- Prefer constructor projection: getFinValue? can fail on non-decide proofs.
    let_expr Fin.mk _ val _p := iWhnf |
      throwError m!"expected Fin.mk after whnf, got {iWhnf}"
    let some valNat := val.nat? |
      throwError m!"expected nat literal Fin.val, got {val}"
    unless valNat == 1 do
      throwError s!"expected elaborated Fin.val = 1 for custom OfNat 0, got {valNat}"
  | .continue none =>
    throwError "reducer declined; cannot discriminate wrong semantics via reduction result"
  | _ => throwError "unexpected reducer step"
  evalTactic (← `(tactic| trivial))

example : True := by
  check_not_std_zero_identity
end WrongSemFirst

import Mathlib.CategoryTheory.ComposableArrows.Basic
open CategoryTheory CategoryTheory.Category CategoryTheory.ComposableArrows
universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X � v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)

section CustomNumeral
local instance : OfNat (Fin 4) 0 := ⟨⟨1, by decide⟩⟩

#reduce (0 : Fin 4)
#reduce Precomp.obj F X (0 : Fin 4)
#reduce Precomp.obj F X ⟨1, by decide⟩
#reduce Precomp.map F f (0 : Fin 4) (0 : Fin 4) (by rfl)

set_option pp.explicit true in
#check Precomp.obj F X 0

example : Precomp.obj F X ⟨1, by decide⟩ = F.obj' 0 := rfl
example : Precomp.obj F X (0 : Fin 4) = F.obj' 0 := rfl
example : Precomp.map F f ⟨1, by decide⟩ ⟨1, by decide⟩ (by decide) = F.map' 0 0 := by
  rfl
example : Precomp.map F f (0 : Fin 4) (0 : Fin 4) (by rfl) = F.map' 0 0 := by
  rfl
end CustomNumeral

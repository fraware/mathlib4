# Environment mitigations (not source changes)

- Full gate runs under detached `tmux` so agent disconnects do not kill Lake.
- A temporary `taskset -c 0,1` lake wrapper caused `MathlibTest.ClickSuggestions.Benchmark` to exceed its 60s wall-clock guard; that wrapper was removed. Failure was environmental, not candidate-related.
- `LEAN_NUM_THREADS=2` retained as a soft lean-process hint only.
- MathlibTest cache left warm after successful standalone Benchmark rebuild.

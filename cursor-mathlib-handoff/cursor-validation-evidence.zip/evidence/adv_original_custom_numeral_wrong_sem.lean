
import Mathlib.CategoryTheory.ComposableArrows.Basic

set_option linter.unusedTactic false
set_option linter.unreachableTactic false

open CategoryTheory CategoryTheory.Category
open CategoryTheory.ComposableArrows

open Lean Meta Elab Tactic in
/-- Inspect the reducer directly so a later `rfl` cannot hide a missing rewrite. -/
private def checkReduceMap (expectVisit : Bool) : TacticM Unit := withMainContext do
  let some (_, lhs, rhs) := (← getMainTarget).eq? |
    throwError "expected an equality goal"
  unless lhs.isAppOf ``Precomp.map do
    throwError "expected Precomp.map on the left"
  let (step, _) ← Simp.SimpM.run (← Simp.Context.mkDefault) (k := Precomp.reduceMap lhs)
  match step with
  | .visit result =>
    unless expectVisit do
      throwError "expected the reducer to decline"
    if result.isAppOf ``Precomp.map then
      throwError "reducer did not unfold Precomp.map"
    unless ← withNewMCtxDepth (isDefEq (← inferType result) (← inferType lhs)) do
      throwError "reducer changed the expression type"
    unless ← withNewMCtxDepth (isDefEq result lhs) do
      throwError "reducer violated definitional equality with its input"
    unless ← withNewMCtxDepth (isDefEq result rhs) do
      throwError "reducer returned an unexpected expression"
  | .continue none =>
    if expectVisit then
      throwError "expected the reducer to visit a reduced expression"
  | _ => throwError "unexpected reducer step"

elab "check_reduce_map_visit" : tactic => checkReduceMap true
elab "check_reduce_map_declines" : tactic => checkReduceMap false

universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)


section CustomNumeralWrongSemantics
local instance : OfNat (Fin (2 + 1 + 1)) 0 := ⟨⟨1, by decide⟩⟩

-- If the reducer canonicalizes to standard OfNat 0 (= ⟨0⟩), it yields 𝟙 X.
-- Preferred must NOT make this succeed; original MAY wrongly succeed.
example : Precomp.map F f 0 0 (by rfl) = 𝟙 X := by
  check_reduce_map_visit
  dsimp only [Precomp.reduceMap] <;> rfl
end CustomNumeralWrongSemantics

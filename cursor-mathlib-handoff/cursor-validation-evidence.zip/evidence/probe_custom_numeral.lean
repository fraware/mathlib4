
import Mathlib.CategoryTheory.ComposableArrows.Basic

open CategoryTheory CategoryTheory.Category
open CategoryTheory.ComposableArrows

universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)

section CustomNumeral
local instance : OfNat (Fin 4) 0 := ⟨⟨1, by decide⟩⟩

#check Precomp.map F f 0 0
#check (Precomp.map F f 0 0 (by rfl) : Precomp.obj F X 0 ⟶ Precomp.obj F X 0)
#check (F.map' 0 0 : F.obj ⟨0, by decide⟩ ⟶ F.obj ⟨0, by decide⟩)

example : Precomp.obj F X 0 = F.obj ⟨0, by decide⟩ := rfl
example : Precomp.map F f 0 0 (by rfl) = (𝟙 (F.obj ⟨0, by decide⟩) : _) := by
  rfl
example : Precomp.map F f 0 0 (by rfl) =
    (F.map' 0 0 : F.obj ⟨0, by decide⟩ ⟶ F.obj ⟨0, by decide⟩) := by
  rfl
end CustomNumeral


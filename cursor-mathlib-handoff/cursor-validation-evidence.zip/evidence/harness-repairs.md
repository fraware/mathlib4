# Harness / reducer repairs (source-level justification)

Error-type vocabulary follows `VALIDATION.md`: environment/dependency,
test-harness API, mistaken expectations, reducer elaboration, semantic
failure, downstream regression.

## 1. OfNat instance carrier type (harness API / mistaken expectation)

Symptom: `CustomNumeral` / `CustomSecondNumeral` failed to elaborate
`F.map' ...` against `Precomp.obj` types.

Cause: `local instance : OfNat (Fin 4) _` is not selected when elaborating
`Precomp.map` indices of type `Fin (n + 1 + 1)` with `n = 2`. Instance
search uses `Fin.instOfNat`, so numeral `0` keeps standard meaning while the
expected RHS assumes the custom meaning.

Change: use `OfNat (Fin (2 + 1 + 1))` for custom/equivalent numeral sections.
Probes: `probe_obj3.*`.

Classification: mistaken test expectation / harness API (instance search),
not a reducer semantic failure.

## 2. LE / Decidable shadowing carrier + priority (harness API)

Retargeted shadowing instances to `Fin (2 + 1 + 1)` with `priority := high`
so they override `instLEFin` during those examples.

Classification: harness API.

## 3. Remove unused/unreachable tactic linter disables (harness API)

Symptom: prior validation disabled `linter.unusedTactic` and
`linter.unreachableTactic` so `lake --iofail test` would accept
inspection-only `check_reduce_map_*` followed by `dsimp ... <;> rfl`.

That disable is assertion-adjacent tooling softening: it hides real unused
or unreachable tactic problems under `--iofail`.

Root-cause fix: make `check_reduce_map_visit` / `check_reduce_map_declines`
perform the Meta visit/decline checks, then close the equality goal with
`rfl` inside the tactic. Examples are a single tactic call. No linter
disables remain. Visit/decline/type/defeq checks are unchanged (not weakened).

Classification: test-harness API repair. Forbidden softening (linter disable)
reversed.

## 4. Empty `lake --iofail test` log integrity (environment / evidence)

Independent audit found `full-3-*.log` of size 0 with recorded exit 0.
That marker is not trustworthy as test evidence. After fingerprint-stable
source is fixed, full is re-run and the test log is required to contain real
build/test output (or an explicit forced rebuild of
`MathlibTest.ComposableArrowsReduceMap` with captured stdout).

Classification: environment / evidence integrity, not reducer semantics.

## Non-changes

- Integrated 13-example probe: byte-identical to HEAD.
- Toolchain unchanged (`v4.35.0-rc3`).
- No `sorry` / `admit` / new axioms / kernel-check disables.
- Preferred reducer design unchanged in this hardening pass.
- Expectations remain 11 visit / 1 decline / 3 baselines per VALIDATION.md.

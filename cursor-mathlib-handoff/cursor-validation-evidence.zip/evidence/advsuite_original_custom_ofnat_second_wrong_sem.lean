
import Mathlib.CategoryTheory.ComposableArrows.Basic

open CategoryTheory CategoryTheory.Category
open CategoryTheory.ComposableArrows
open Lean Meta Elab Tactic

/-- Inspect reducer then close by rfl (same contract as preferred harness). -/
private def checkReduceMap (expectVisit : Bool) : TacticM Unit := withMainContext do
  let some (_, lhs, rhs) := (← getMainTarget).eq? |
    throwError "expected an equality goal"
  unless lhs.isAppOf ``Precomp.map do
    throwError "expected Precomp.map on the left"
  let (step, _) ← Simp.SimpM.run (← Simp.Context.mkDefault) (k := Precomp.reduceMap lhs)
  match step with
  | .visit result =>
    unless expectVisit do
      throwError "expected the reducer to decline"
    if result.isAppOf ``Precomp.map then
      throwError "reducer did not unfold Precomp.map"
    unless ← withNewMCtxDepth (isDefEq (← inferType result) (← inferType lhs)) do
      throwError "reducer changed the expression type"
    unless ← withNewMCtxDepth (isDefEq result lhs) do
      throwError "reducer violated definitional equality with its input"
    unless ← withNewMCtxDepth (isDefEq result rhs) do
      throwError "reducer returned an unexpected expression"
  | .continue none =>
    if expectVisit then
      throwError "expected the reducer to visit a reduced expression"
  | _ => throwError "unexpected reducer step"
  evalTactic (← `(tactic| rfl))

elab "check_reduce_map_visit" : tactic => checkReduceMap true
elab "check_reduce_map_declines" : tactic => checkReduceMap false

universe u v
variable {C : Type u} [Category.{v} C]
variable (F : ComposableArrows C 2) {X : C} (f : X ⟶ F.left)

section WrongSemSecond
local instance : OfNat (Fin (2 + 1 + 1)) 2 := ⟨⟨3, by decide⟩⟩

open Lean Meta Elab Tactic in
elab "check_not_std_two_meaning" : tactic => withMainContext do
  let lhs ← elabTerm (← `(Precomp.map F f (1 : Fin (2 + 1 + 1)) (2 : Fin (2 + 1 + 1)) (by decide))) none
  let expected ← elabTerm (← `(F.map' 0 2)) none
  -- Standard numeral 2 would be ⟨2⟩, giving F.map' 0 1 rather than F.map' 0 2.
  let wrong ← elabTerm (← `(F.map' 0 1)) none
  let (step, _) ← Simp.SimpM.run (← Simp.Context.mkDefault) (k := Precomp.reduceMap lhs)
  match step with
  | .visit result =>
    unless ← withNewMCtxDepth (isDefEq (← inferType result) (← inferType lhs)) do
      throwError "reducer changed the expression type (wrong-sem / reconstruction)"
    unless ← withNewMCtxDepth (isDefEq result expected) do
      throwError "reducer did not produce the custom-OfNat meaning F.map' 0 2"
    if ← withNewMCtxDepth (isDefEq result wrong) then
      throwError "WRONG SEMANTICS: reduced form matches standard-numeral meaning F.map' 0 1"
    let_expr Precomp.map _C _inst _n _F _X _f _i j _hij := lhs |
      throwError "expected Precomp.map application"
    let jWhnf ← whnf j
    let_expr Fin.mk _ val _p := jWhnf |
      throwError m!"expected Fin.mk after whnf, got {jWhnf}"
    let some valNat := val.nat? |
      throwError m!"expected nat literal Fin.val, got {val}"
    unless valNat == 3 do
      throwError s!"expected elaborated Fin.val = 3 for custom OfNat 2, got {valNat}"
  | .continue none =>
    throwError "reducer declined; cannot discriminate wrong semantics via reduction result"
  | _ => throwError "unexpected reducer step"
  evalTactic (← `(tactic| trivial))

example : True := by
  check_not_std_two_meaning
end WrongSemSecond
